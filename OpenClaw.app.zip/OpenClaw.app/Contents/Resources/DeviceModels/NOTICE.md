# Apple device identifier mappings

This directory includes model identifier → human-readable name mappings derived from the open-source project:

- `kyle-seongwoo-jun/apple-device-identifiers`
  - iOS mapping pinned to commit `8e7388b29da046183f5d976eb74dbb2f2acda955`
  - macOS mapping pinned to commit `98ca75324f7a88c1649eb5edfc266ef47b7b8193`

See `LICENSE.apple-device-identifiers.txt` for license terms.
